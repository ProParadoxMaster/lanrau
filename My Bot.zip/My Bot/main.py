from pyrogram import Client
import json
from FUNC.server_stats import *  # Assuming this handles server status or other tasks

# Plugins root directory
plugins = dict(root="BOT")

# Load configuration from the config.json file
with open("FILES/config.json", "r", encoding="utf-8") as f:
    DATA      = json.load(f)
    API_ID    = DATA["API_ID"]
    API_HASH  = DATA["API_HASH"]
    BOT_TOKEN = DATA["BOT_TOKEN"]

# Create the bot client
bot = Client(
    "MY_BOT", 
    api_id    = API_ID, 
    api_hash  = API_HASH, 
    bot_token = BOT_TOKEN, 
    plugins   = plugins
)

if __name__ == "__main__":
    # Optionally, you can call any initial setup functions like server alerts
    # send_server_alert()

    print("Done Bot Active ✅")
    print("NOW START BOT ONCE")

    # Run the bot
    bot.run()