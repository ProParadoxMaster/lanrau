import json
from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton

REGISTER_USERS_FILE = "Files/registerusers.json"


# Check if a user is registered
def is_registered(user_id):
    try:
        with open(REGISTER_USERS_FILE, "r") as f:
            data = json.load(f)
            return user_id in [user["user_id"] for user in data["registered_users"]]
    except FileNotFoundError:
        return False

# Add a user to the registered list
def register_user(user_id, username):
    try:
        with open(REGISTER_USERS_FILE, "r") as f:
            data = json.load(f)
    except FileNotFoundError:
        data = {"registered_users": []}

    if user_id not in [user["user_id"] for user in data["registered_users"]]:
        data["registered_users"].append({"user_id": user_id, "username": username})
        with open(REGISTER_USERS_FILE, "w") as f:
            json.dump(data, f, indent=4)


@Client.on_message(filters.command("start"))
async def start(bot, message):
    user_id = message.from_user.id
    username = message.from_user.username or "Unknown"

    if is_registered(user_id):
        await message.reply_text(
            f"🌟 Hello {username}!\n\n"
            f"Welcome aboard the Checker! 🚀\n\n"
            f"I am your go-to bot, packed with a variety of gates, tools, and commands to enhance your experience. Excited to see what I can do?\n\n"
            f"👇 Tap the Register button to begin your journey.\n"
            f"👇 Discover my full capabilities by tapping the Commands button.\n"
            f"👇 Click Close Button For Back",
            reply_markup=InlineKeyboardMarkup(WELCOME_BUTTON)
        )
    else:
        await message.reply_text(
            f"🌟 Hello {username}!\n\n"
            f"Welcome aboard the Checker! 🚀\n\n"
            f"To start using the bot, you need to register first. Please click on the Register button below to proceed.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Register", callback_data="register")],
                [InlineKeyboardButton("Close", callback_data="close")]
            ])
        )


@Client.on_callback_query(filters.regex("register"))
async def register_user_callback(bot, query):
    user_id = query.from_user.id
    username = query.from_user.username or "Unknown"

    if is_registered(user_id):
        await query.message.edit_text(
            f"✅ You are already registered!\n\n"
            f"• Name         » {username}\n"
            f"• Status       » REGISTERED\n"
            f"• Credits      » 0\n"
            f"• User ID      » {user_id}\n",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("Back", callback_data="back_to_cmds")],
                [InlineKeyboardButton("Cancel", callback_data="cancel")]
            ])
        )
        return

    # Register the user
    register_user(user_id, username)

    await query.message.edit_text(
        f"✅ Successfully Registered!\n\n"
        f"• Name         » {username}\n"
        f"• Status       » REGISTERED\n"
        f"• Credits      » 0\n"
        f"• User ID      » {user_id}\n",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("Back", callback_data="back_to_cmds")],
            [InlineKeyboardButton("Cancel", callback_data="cancel")]
        ])
    )


@Client.on_callback_query(filters.regex("cmds"))
async def show_commands(bot, query):
    user_id = query.from_user.id
    if not is_registered(user_id):
        await query.answer("❌ You must register first!", show_alert=True)
        return


# Initial inline keyboard for /start
WELCOME_BUTTON = [
    [
        InlineKeyboardButton("Register", callback_data="register"),
        InlineKeyboardButton("Commands", callback_data="cmds")
    ],
    [
        InlineKeyboardButton("Close", callback_data="close")
    ]
]

# Commands inline keyboard
COMMANDS_BUTTON = [
    [
        InlineKeyboardButton("Getaway", callback_data="getaway"),
        InlineKeyboardButton("Tool", callback_data="tool")
    ],
    [
        InlineKeyboardButton("Price", callback_data="price"),
        InlineKeyboardButton("Exit", callback_data="exit")
    ]
]

# Getaway inline keyboard
GETAWAY_BUTTON = [
    [
        InlineKeyboardButton("Auth", callback_data="auth"),
        InlineKeyboardButton("Charge", callback_data="charge")
    ],
    [
        InlineKeyboardButton("Back", callback_data="back_to_cmds")
    ]
]


@Client.on_callback_query(filters.regex("auth"))
async def show_auth_gateways(bot, query):
    # Read authcfg.json file
    try:
        with open("Files/authcfg.json", "r") as f:
            gateways = json.load(f)

        # Generate response for all gateways in authcfg.json
        message = "↯ Available Auth Gateways:\n\n"
        for index, gateway in enumerate(gateways, start=1):
            message += (
                f"AUTH GATEWAY [ P~{index} ]\n"
                f"↯ Name  »  {gateway['GATEWAY_NAME']} (/{gateway['GATEWAY_CMD']})\n"
                f"• Status ⌁  {'PREMIUM' if gateway['IS_PREMIUM'] == 'TRUE' else 'FREE'} » {gateway['IS_WORKING']}\n"
                f"• Gateway ⌁  {gateway['REAL_NAME']}\n"
                f"• Format ⌁  {gateway['CC_FORMAT']}\n"
                f"• Credits Needed ⌁  {gateway['CRADITS_NEEDS']} » {gateway['TOTAL_CRADIT_NEED']}\n"
                f"• Antispam ⌁  {gateway['ANTISPAM']}\n\n"
            )

        # Send the generated message
        await query.message.edit_text(
            message,
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Back", callback_data="back_to_getaway")]])
        )
    except Exception as e:
        await query.message.edit_text(
            "❌ Failed to load Auth Gateways. Please check the configuration file."
        )


@Client.on_callback_query(filters.regex("charge"))
async def show_charge_gateways(bot, query):
    # Read chargecfg.json file
    try:
        with open("Files/chargecfg.json", "r") as f:
            gateways = json.load(f)

        # Generate response for all gateways in chargecfg.json
        message = "↯ Available Charge Gateways:\n\n"
        for index, gateway in enumerate(gateways, start=1):
            message += (
                f"CHARGE GATEWAY [ P~{index} ]\n"
                f"↯ Name  »  {gateway['GATEWAY_NAME']} (/{gateway['GATEWAY_CMD']})\n"
                f"• Status ⌁  {'PREMIUM' if gateway['IS_PREMIUM'] == 'TRUE' else 'FREE'} » {gateway['IS_WORKING']}\n"
                f"• Gateway ⌁  {gateway['REAL_NAME']}\n"
                f"• Format ⌁  {gateway['CC_FORMAT']}\n"
                f"• Credits Needed ⌁  {gateway['CRADITS_NEEDS']} » {gateway['TOTAL_CRADIT_NEED']}\n"
                f"• Antispam ⌁  {gateway['ANTISPAM']}\n\n"
            )

        # Send the generated message
        await query.message.edit_text(
            message,
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("Back", callback_data="back_to_getaway")]])
        )
    except Exception as e:
        await query.message.edit_text(
            "❌ Failed to load Charge Gateways. Please check the configuration file."
        )


@Client.on_callback_query(filters.regex("back_to_getaway"))
async def back_to_getaway(bot, query):
    # Return to getaway menu
    await query.message.edit_text(
        "🚪 We are currently adding gates. Check below to view available gates:\n\n"
        "View full list of gateways:",
        reply_markup=InlineKeyboardMarkup(GETAWAY_BUTTON)
    )


@Client.on_callback_query(filters.regex("back_to_cmds"))
async def back_to_commands(bot, query):
    # Return to commands menu
    await query.message.edit_text(
        f"🌟 Hello {query.from_user.first_name}!\n\n"
        "GrandPaa Checker has plenty of Commands. We have Auth Gates, Charge Gates, Tools, and other things.\n\n"
        "Click each of them below to know them better.",
        reply_markup=InlineKeyboardMarkup(COMMANDS_BUTTON)
    )